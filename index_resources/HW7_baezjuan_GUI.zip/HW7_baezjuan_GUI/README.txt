Juan Baez

HW7 LINK: https://baezrjuan.github.io/index_resources/HW7_baezjuan_GUI/hw7.html
Git REPO LINK: https://github.com/baezrjuan/baezrjuan.github.io/tree/master/index_resources/HW7_baezjuan_GUI

Enter 4 numbers that are validated in real time by jquery.
	Use either text or sliders to change numbers. The numbers will be entered in the tab title.
Click submit to calculate table.
Click Open New Tab to create a new tab.
Enter one or multiple table numbers you want to delete in the delete textbox. 
	Click Delete when ready and the tabs will be removed. (ISSUE: only works once)

